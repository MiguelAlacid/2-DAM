package start;

public class Inicio {

	public static void main(String[] args) {
		
		ctrl.GestFch.inicio();

	}

	

}
